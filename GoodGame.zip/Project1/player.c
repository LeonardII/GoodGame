#include "player.h"
#include <stdlib.h>

Player* Player_initPlayerOverload(double movementSpeed, Vector2D position, SDL_Renderer *renderer)
{
	Player* player;
	int *radius = malloc(sizeof(int));
	player = malloc(sizeof(Player));
	player->transform = malloc(sizeof(Transform));
	player->movementSpeed = movementSpeed;
	player->transform->position = position;
	Transform_setDirection(player->transform, Vector2D_initEmpty());
	player->circleCollider.anchor = player->transform->position;
	player->texture = Draw_loadTexture(TEXTURE_PLAYER_FILENAME, renderer, radius);
	player->textureDirection = Vector2D_initVector2D(0, 1);
	player->circleCollider.radius = *radius / (double) 2.2;
	free(radius);

	Vector2D weaponPosition = Vector2D_add(player->transform->position, Vector2D_multiply(player->textureDirection, player->circleCollider.radius * 2));
	Vector2D directionWeapon = player->textureDirection;
	player->weapon = Weapon_initWeapon(weaponPosition, directionWeapon, renderer);
	player->isAlive = 1;
	return player;
}
Player* Player_initPlayer(double movementSpeed, Transform *transform, SDL_Renderer *renderer)
{
	Player *player;
	int *radius = malloc(sizeof(int));
	player = malloc(sizeof(Player));
	player->transform = malloc(sizeof(Transform));
	player->movementSpeed = movementSpeed;
	player->transform = transform;
	player->circleCollider.anchor = player->transform->position;
	player->texture = Draw_loadTexture(TEXTURE_PLAYER_FILENAME, renderer, radius);
	player->circleCollider.radius = *radius / (double)2.2;
	free(radius);

	Vector2D weaponPosition = Vector2D_add(player->transform->position, Vector2D_multiply(player->textureDirection, player->circleCollider.radius * 2));
	Vector2D directionWeapon = player->textureDirection;
	player->weapon = Weapon_initWeapon(weaponPosition, directionWeapon, renderer);
	player->isAlive = 1;

	return player;
}
void Player_move(Player *player, SDL_Renderer *renderer, double deltaTime)
{
	if (!player->isAlive)
	{
		return;
	}
	if (player->timeLengthOfKnockback > 0)
	{
		Transform_Move(player->transform, deltaTime * player->movementSpeed * 4);
	}
	else
	{
		Transform_Move(player->transform, deltaTime * player->movementSpeed);
	}
	player->circleCollider.anchor = player->transform->position;
}

void Player_moveWithNewDirection(Player * player, SDL_Renderer *renderer, Vector2D newDirection, double deltaTime)
{
	if (player->timeLengthOfKnockback > 0)
	{
		player->timeLengthOfKnockback -= deltaTime / (double)1000;
		Player_move(player, renderer, deltaTime);
		return;
	}
	if (Vector2D_equals(newDirection, Vector2D_initEmpty()))
	{
		return;
	}
	Transform_setDirection(player->transform, newDirection);
	Player_move(player, renderer, deltaTime);
}
void Player_receiveKnockback(Player * player, double timeLengthofKnockback)
{
	player->timeLengthOfKnockback = timeLengthofKnockback;
	Transform_setDirection(player->transform, Vector2D_subtract(Vector2D_initEmpty(), player->textureDirection));
}
void Player_show(Player * player, SDL_Renderer * renderer)
{
	Draw_drawTexture(player->texture, renderer, player->transform->position);
	Weapon_show(player->weapon, renderer);
}
void Player_showWithNewDirection(Player * player, SDL_Renderer * renderer, Vector2D textureDirection)
{
	player->textureDirection = textureDirection;
	Draw_drawTextureWithAngle(player->texture, renderer, player->transform->position, textureDirection);

	Vector2D weaponPosition = Vector2D_add(player->transform->position, Vector2D_multiply(Vector2D_toUnit(player->textureDirection), player->circleCollider.radius * 2));
	Weapon_resetPosition(player->weapon, weaponPosition);
	Weapon_resetDirection(player->weapon, player->textureDirection);
	Weapon_show(player->weapon, renderer);
}

void Player_die(Player * player)
{
	player->isAlive = 0;
}

//"Private" functions, they are not included in the header.

//Prints the current position to check possible errors.
int Player_getPosition(Player *player)
{
	printf_s("Current position: P(%f, %f) \n", player->transform->position.x, player->transform->position.y);
}
int Player_getDirection(Player *player)
{
	printf_s("Current direction: P(%f, %f) \n", player->transform->direction.x, player->transform->direction.y);
}
