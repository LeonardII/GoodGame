#include <stdlib.h>
#include "bullet.h"

Bullet *Bullet_initBullet(Vector2D position, Vector2D direction, SDL_Renderer *renderer, WeaponClass weaponClass, unsigned short damage, double knockbackTime, double totalRange)
{
	Bullet *bullet = malloc(sizeof(Bullet));
	bullet->transform = malloc(sizeof(Transform));
	bullet->transform->position = position;
	Transform_setDirection(bullet->transform, direction);
	bullet->circleCollider.anchor = bullet->transform->position;
	int diameter = 0;
	bullet->texture = Draw_loadTexture(TEXTURE_BULLET_FILENAME, renderer, &diameter);
	bullet->circleCollider.radius = diameter / 2;

	bullet->weaponClass = weaponClass;
	bullet->damage = damage;
	bullet->knockbackTime = knockbackTime;
	bullet->remainingRange = totalRange;
	bullet->speed = (unsigned short) bullet->remainingRange / 200;
	return bullet;
}
int Bullet_move(Bullet * bullet, double deltaTime)
{
    Vector2D positionBefore = bullet->transform->position;
	Transform_Move(bullet->transform, deltaTime * bullet->speed);
	bullet->circleCollider.anchor = bullet->transform->position;
	bullet->remainingRange -= Vector2D_getMagnitude(Vector2D_subtract(bullet->transform->position, positionBefore));
	if (bullet->remainingRange <= 0)
	{
		free(bullet);
		return 1;
	}
	return 0;
}

void Bullet_show(Bullet *bullet, SDL_Renderer *renderer)
{
	Draw_drawTextureWithAngle(bullet->texture, renderer, bullet->transform->position, bullet->transform->direction);
}

void Bullet_destroy(Bullet * bullet)
{
	free(bullet);
}

