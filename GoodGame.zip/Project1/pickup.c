#include "pickup.h"

PickUp * PickUp_initRandomPickUp(Vector2D position, SDL_Renderer * renderer)
{
	PickUp *pickup = malloc(sizeof(PickUp));
	pickup->transform = malloc(sizeof(Transform));
	pickup->weaponDrop = (WeaponClass)rand() % 5;
	pickup->transform->position = position;
	pickup->circleCollider.anchor = position;
	int diameter = 0;
	char* filename = NULL;
	switch (pickup->weaponDrop)
	{
	case Pistol:
		filename = TEXTURE_PICKUP_PISTOL_FILENAME;
		break;
	case Sniper:
		filename = TEXTURE_PICKUP_SNIPER_FILENAME;
		break;
	case MachinePistol:
		filename = TEXTURE_PICKUP_MACHINEPISTOL_FILENAME;
		break;
	case AssaultRifle:
		filename = TEXTURE_PICKUP_ASSAULTRIFLE_FILENAME;
		break;
	case MachineGun:
		filename = TEXTURE_PICKUP_MACHINEGUN_FILENAME;
		break;
	}
	pickup->texture = Draw_loadTexture(filename, renderer, &diameter);
	pickup->circleCollider.radius = diameter / 2;
	return pickup;
}

void PickUp_show(PickUp * pickUp, SDL_Renderer * renderer)
{
	Draw_drawTextureWithAngle(pickUp->texture, renderer, pickUp->transform->position, pickUp->transform->direction);
}

int PickUp_grantPlayerWeaponIfColliding(PickUp * pickup, Player * player)
{
	if (CircleCollider_isColliding(pickup->circleCollider, player->circleCollider))
	{
		switch (pickup->weaponDrop)
		{
		case Pistol:
			Weapon_turnIntoPistol(player->weapon);
			break;
		case Sniper:
			Weapon_turnIntoSniper(player->weapon);
			break;
		case MachinePistol:
			Weapon_turnIntoMachinePistol(player->weapon);
			break;
		case AssaultRifle:
			Weapon_turnIntoAssaultRifle(player->weapon);
			break;
		case MachineGun:
			Weapon_turnIntoMachineGun(player->weapon);
			break;
		default:
			break;
		}
		free(pickup);
		return 1;
	}
	return 0;
}
