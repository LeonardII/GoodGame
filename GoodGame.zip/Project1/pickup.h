#ifndef PICKUP_H
#define PICKUP_H
#include "transform.h"
#include "collider.h"
#include "weapon.h"
#include "bullet.h"
#include "player.h"
#define TEXTURE_PICKUP_SNIPER_FILENAME "PickUp_Sniper.png"
#define TEXTURE_PICKUP_PISTOL_FILENAME "PickUp_Pistol.png"
#define TEXTURE_PICKUP_ASSAULTRIFLE_FILENAME "PickUp_AssaultRifle.png"
#define TEXTURE_PICKUP_MACHINEPISTOL_FILENAME "PickUp_MachinePistol.png"
#define TEXTURE_PICKUP_MACHINEGUN_FILENAME "PickUp_MachineGun.png"

typedef struct
{
	Transform *transform;
	CircleCollider circleCollider;
	WeaponClass weaponDrop;
	SDL_Texture *texture;
}PickUp;
PickUp *PickUp_initPickUp(SDL_Renderer *renderer, Vector2D position, WeaponClass weaponClass);
PickUp *PickUp_initRandomPickUp(Vector2D position, SDL_Renderer *renderer);
void PickUp_show(PickUp *pickUp, SDL_Renderer *renderer);
int PickUp_grantPlayerWeaponIfColliding(PickUp *pickup, Player *player);
#endif
