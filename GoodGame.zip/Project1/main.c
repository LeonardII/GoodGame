#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "SDL_mixer.h"
#include "player.h"
#include "lists.h"
#include "map.h"
#include "SDL_ttf.h"

#define FPS 200
#define DELTATIME 1000 / FPS
#define GAME_WIDTH 1500
#define GAME_HEIGHT 1000
#define ENEMY_SPAWN_PERIOD 100
#define ENEMY_SPAWN_PROPABILITY 6
#define DROP_PROBABILITY 30
#define MUSIC_MAIN_FILENAME "Theme_Main.wav"
#define MUSIC_ZOMBIE_FILENAME "Sound_Zombie.wav"
#define MUSIC_PICKUP_FILENAME "Sound_PickUp.wav"
#define MUSIC_BULLET_FILENAME "Sound_Bullet.wav"
SDL_Renderer *windowRenderer;
SDL_Window *gameWindow;
SDL_Event *event;
BulletList *bulletList;
ZombieList *zombieList;
PickUpList *pickupList;
BloodList *bloodList;
Player *player;
Vector2D mousePos;
Map *map;
Mix_Chunk *song;
Mix_Chunk *pickupSound;
Mix_Chunk *zombieSound;
Mix_Chunk *bulletSound;
SDL_Surface* surfaceMessage;
SDL_Texture* message;
TTF_Font* sans;
int keys[5] = { 0, 0, 0, 0, 0 };
int timeTillSpawn = ENEMY_SPAWN_PERIOD;
int isGameOver = 0;

int main()
{
	int flags = IMG_INIT_PNG;
	int initted = IMG_Init(flags);
	if ((initted&flags) != flags)
	{
		printf("IMG_Init: Failed to init required jpg and png support!\n");
		printf("IMG_Init: %s\n", IMG_GetError());
		// handle error
	}
	SDL_Init(SDL_INIT_EVERYTHING);
	TTF_Init();
	startGame();
	while (!isGameOver)
	{
		update();
		SDL_Delay(DELTATIME);
	}
	loadGameOver();
	return 7171;
}
//Loads mandatory variables needed for the game and the window. 
int startGame()
{
	srand(time(NULL));   // Initialization, should only be called once.
	event = malloc(sizeof(SDL_Event));
	gameWindow = SDL_CreateWindow("Ultimate Zombie Slasher 2019", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, GAME_WIDTH, GAME_HEIGHT, SDL_WINDOW_SHOWN);
	windowRenderer = SDL_CreateRenderer(gameWindow, -1, 0);
	map = Map_initMap(Vector2D_initEmpty(), windowRenderer, GAME_WIDTH, GAME_HEIGHT);
	player = Player_initPlayerOverload(0.5, Vector2D_initVector2D(0, 0), windowRenderer);
	Weapon_turnIntoPistol(player->weapon);
	bulletList = BulletList_initBulletList();
	zombieList = ZombieList_initZombieList();
	bloodList = BloodList_initBloodList();
	pickupList = PickUpList_initPickUpList();
	surfaceMessage = malloc(sizeof(SDL_Surface));
	sans = TTF_OpenFont("FreeSans.ttf", 45); //this opens a font style and sets a size
	loadWindow();
	setupMap();
	activateSongChannels();
	Mix_PlayChannel(0, song, 65000);
}
//Updates functions such as movement and rendering.
int update()
{
	checkInputs();
	applyUpdate();
	checkColliders();
	renderObjects();
}
//Moves all instances in the game.
int applyUpdate()
{
	Vector2D directionToMove = Vector2D_initVector2D(keys[1] - keys[0], keys[3] - keys[2]);
	Player_moveWithNewDirection(player, windowRenderer, directionToMove, DELTATIME);
	if (keys[4] == 1)
	{
		Bullet *bullet = Weapon_tryToShoot(player->weapon, windowRenderer);
		if (bullet != NULL)
		{
			Player_receiveKnockback(player, bullet->knockbackTime / 10);
			BulletList_add(bulletList, bullet);
			Mix_PlayChannel(-1, bulletSound, 0);
		}
	}
	ZombieList_moveZombies(zombieList, DELTATIME);
	BulletList_moveBullets(bulletList, DELTATIME);
	Weapon_decreaseCooldown(player->weapon, DELTATIME);
	preventGoingOutsideWindow();
	if (player->weapon->amountAmmunition == 0 && pickupList->length == 0)
	{
		prepareEnmergencyPickUp();
	}
	timeTillSpawn -= DELTATIME;
	if (timeTillSpawn <= 0)
	{
		timeTillSpawn = ENEMY_SPAWN_PERIOD;
		spawnZombie();
	}
}
//Renders all instances in the game.
//If something should be on top of something else, then render it last.
int renderObjects()
{
	SDL_RenderClear(windowRenderer);
	BloodList_renderBloods(bloodList, windowRenderer);
	PickUpList_renderPickUps(pickupList, windowRenderer);
	BulletList_renderBullets(bulletList, windowRenderer);
	Player_showWithNewDirection(player, windowRenderer, Vector2D_subtract(mousePos, player->transform->position));
	ZombieList_renderZombies(zombieList, windowRenderer);
	Map_renderMap(map, windowRenderer);
	if(keys[4])
	displayAmmunition();
	SDL_RenderPresent(windowRenderer);
}
int checkColliders()
{
	if (List_applyDamageOnZombiesOnCollide(bulletList, zombieList, bloodList, pickupList, DROP_PROBABILITY, windowRenderer))
	{
		Mix_PlayChannel(-1, zombieSound, 0);
	}
	if (PickUpList_checkCollidingwithPlayer(pickupList, player))
	{
		Mix_PlayChannel(-1, pickupSound, 0);
	}
	ZombieList_preventZombiesFromColliding(zombieList);
	Map_preventPlayerFromColliding(map, player);
	Map_preventZombiesFromColliding(map, zombieList);
	Map_destroyBulletsAtColliding(map, bulletList);

	if (ZombieList_tryToHitPlayer(player, zombieList))
	{
		isGameOver = 1;
	}
}
//Sets the global variables such as mouse position and keys by checking the gamer input.
int checkInputs()
{
	int mouseX, mouseY;
	SDL_GetMouseState(&mouseX, &mouseY);
	mousePos = Vector2D_initVector2D(mouseX, mouseY);
	if (SDL_PollEvent(event))
	{
		switch (event->type)
		{
		case SDL_KEYDOWN:
			switch (event->key.keysym.sym)
			{
			case SDLK_a:
				keys[0] = 1;
				break;
			case SDLK_d:
				keys[1] = 1;
				break;
			case SDLK_w:
				keys[2] = 1;
				break;
			case SDLK_s:
				keys[3] = 1;
				break;
			case SDLK_SPACE:
				keys[4] = 1;
				break;
			}
			break;

		case SDL_KEYUP:
			switch (event->key.keysym.sym)
			{
			case SDLK_a:
				keys[0] = 0;
				break;
			case SDLK_d:
				keys[1] = 0;
				break;
			case SDLK_w:
				keys[2] = 0;
				break;
			case SDLK_s:
				keys[3] = 0;
				break;
			case SDLK_SPACE:
				keys[4] = 0;
				break;
			}
			break;
		case SDL_QUIT:
			exit(1337);
			break;
		}

	}
}
int loadWindow()
{
	/*Initializes everything needed for a media: sound, graphics, controls...*/
	//SDL_SetWindowFullscreen(gameWindow, SDL_WINDOW_FULLSCREEN);
	SDL_SetRenderDrawColor(windowRenderer, 15, 15, 15, 50);
	SDL_RenderClear(windowRenderer);
	SDL_RenderPresent(windowRenderer);
}
int preventGoingOutsideWindow()
{
	Vector2D positionToCorrect = player->transform->position;
	if (player->transform->position.x - player->circleCollider.radius < 0)
	{
		positionToCorrect.x = player->circleCollider.radius;
	}
	else if (player->transform->position.x + player->circleCollider.radius >= GAME_WIDTH)
	{
		positionToCorrect.x = GAME_WIDTH - player->circleCollider.radius;
	}
	if (player->transform->position.y - player->circleCollider.radius < 0)
	{
		positionToCorrect.y = player->circleCollider.radius;
	}
	else if (player->transform->position.y + player->circleCollider.radius >= GAME_HEIGHT)
	{
		positionToCorrect.y = GAME_HEIGHT - player->circleCollider.radius;
	}
	if (!Vector2D_equals(positionToCorrect, player->transform->position))
	{
		player->transform->position = positionToCorrect;
	}
}
int spawnZombie()
{
	if (ENEMY_SPAWN_PROPABILITY < rand() % 101)
	{
		//Spawning failed.
		return;
	}
	while (1)
	{
		int random_X = rand() % GAME_WIDTH;      // Returns a pseudo-random integer between 0 and GAME_WIDTH.
		int random_Y = rand() % GAME_HEIGHT;
		Vector2D spawnPosition = Vector2D_initVector2D(random_X, random_Y);
		if (Vector2D_getMagnitude(Vector2D_subtract(player->transform->position, spawnPosition)) >= 600)
		{
			Zombie *zombie = Enemy_spawnZombie(player, spawnPosition, windowRenderer);
			ZombieList_add(zombieList, zombie);
			break;
		}
	}
}
int setupMap()
{
	Map_setPillar(map, 0, Vector2D_initVector2D(150, 150));
	Map_setPillar(map, 1, Vector2D_add(map->pillars[0]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * 2, 0)));
	Map_setPillar(map, 2, Vector2D_add(map->pillars[1]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * 2, 0)));
	Map_setPillar(map, 3, Vector2D_add(map->pillars[2]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * 2, 0)));
	Map_setPillar(map, 4, Vector2D_add(map->pillars[3]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * 2, 0)));
	Map_setPillar(map, 5, Vector2D_add(map->pillars[4]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * 2, 0)));
	Map_setPillar(map, 6, Vector2D_initVector2D(GAME_WIDTH - 150, GAME_HEIGHT - 150));
	Map_setPillar(map, 7, Vector2D_subtract(map->pillars[6]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * sqrt(2), map->pillars[0]->circleCollider.radius * sqrt(2))));
	Map_setPillar(map, 8, Vector2D_subtract(map->pillars[7]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * sqrt(2), map->pillars[0]->circleCollider.radius  * sqrt(2))));
	Map_setPillar(map, 9, Vector2D_subtract(map->pillars[8]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * sqrt(2), map->pillars[0]->circleCollider.radius  * sqrt(2))));
	Map_setPillar(map, 10, Vector2D_subtract(map->pillars[9]->transform->position, Vector2D_initVector2D(map->pillars[0]->circleCollider.radius * sqrt(2), map->pillars[0]->circleCollider.radius * sqrt(2))));
	Map_setPillar(map, 11, Vector2D_initVector2D(150, GAME_HEIGHT - 150));
}
int loadGameOver()
{
	printf_s("You lost against the horde of %u zombies and were eaten sucessfully!\n", zombieList->length);
	printf_s("How does it feel to have eradicated %u zombies? \n", bloodList->length);
	SDL_SetRenderDrawColor(windowRenderer, 0, 0, 0, 50);
	keys[4] = 0;
	Mix_Volume(-1, 16);
	for (double i = 0; i <= 2 / (DELTATIME / (double)1000); i++)
	{
		timeTillSpawn = 9999;
		applyUpdate();
		checkColliders();
		renderObjects();
		SDL_Delay(DELTATIME);
	}
	exit(7171);
}
int activateSongChannels()
{
	int result = Mix_OpenAudio(44100, AUDIO_S16SYS, 2, 512);
	if (result < 0)
	{
		fprintf(stderr, "Unable to open audio: %s\n", SDL_GetError());
		exit(-1);
	}

	result = Mix_AllocateChannels(20);
	if (result < 0)
	{
		fprintf(stderr, "Unable to allocate mixing channels: %s\n", SDL_GetError());
		exit(-1);
	}
	song = Mix_LoadWAV(MUSIC_MAIN_FILENAME);
	bulletSound = Mix_LoadWAV(MUSIC_BULLET_FILENAME);
	pickupSound = Mix_LoadWAV(MUSIC_PICKUP_FILENAME);
	zombieSound = Mix_LoadWAV(MUSIC_ZOMBIE_FILENAME);
	Mix_Volume(0, 32);
}
int displayAmmunition()
{
	int length = snprintf(NULL, 0, "%d", player->weapon->amountAmmunition);
	char* str = malloc(length + 1);
	snprintf(str, length + 1, "%d", player->weapon->amountAmmunition);
	SDL_Color displayColor = { 255, 255, 255 };  // this is the color in rgb format, maxing out all would give you the color white, and it will be your text's color
	if (player->weapon->amountAmmunition <= 2)
	{
		SDL_Color displayColor2 = { 255, 25, 25 };
		displayColor = displayColor2;
	}
	if (str == NULL)
	{
		return;
	}
	surfaceMessage = TTF_RenderText_Solid(sans, str, displayColor); // as TTF_RenderText_Solid could only be used on SDL_Surface then you have to create the surface first

	message = SDL_CreateTextureFromSurface(windowRenderer, surfaceMessage); //now you can convert it into a texture
	SDL_Rect message_rect; //create a rect

	//Mind you that (0,0) is on the top left of the window/screen, think a rect as the text's box, that way it would be very simple to understance

	//Now since it's a texture, you have to put RenderCopy in your game loop area, the area where the whole code executes
	SDL_QueryTexture(message, NULL, NULL, &message_rect.w, &message_rect.h);
	message_rect.x = GAME_WIDTH - message_rect.w - 10;
	message_rect.y = GAME_HEIGHT - message_rect.h - 10;
	SDL_RenderCopy(windowRenderer, message, NULL, &message_rect);
}
int prepareEnmergencyPickUp()
{
	PickUp *pickUp = PickUp_initRandomPickUp(Vector2D_initVector2D(GAME_WIDTH / 2, GAME_HEIGHT / 2), windowRenderer);
	PickUpList_add(pickupList, pickUp);
}