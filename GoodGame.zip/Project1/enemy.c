#include "enemy.h"

Zombie *Enemy_spawnZombie(Player *target, Vector2D spawnPosition, SDL_Renderer *renderer)
{
	Zombie *zombie = malloc(sizeof(Zombie));
	zombie->transform = malloc(sizeof(Transform));
	zombie->transform->position = spawnPosition;
	zombie->circleCollider.anchor = spawnPosition;
	int diameter = 0;
	zombie->texture = Draw_loadTexture(TEXTURE_ZOMBIE_FILENAME, renderer, &diameter);
	zombie->circleCollider.radius = diameter / 2;
	zombie->transformTarget = target->transform;

	zombie->health = HEALTH;
	zombie->movementSpeed = MOVEMENT_SPEED;

	return zombie;
}

void Enemy_moveZombie(Zombie *zombie, double deltaTime)
{
	if (zombie->knockbackTime > 0)
	{
		zombie->knockbackTime -= deltaTime / (1000);
		return;
	}
	Vector2D directionToTarget = Vector2D_subtract(zombie->transformTarget->position, zombie->transform->position);
	Transform_setDirection(zombie->transform, directionToTarget);
	Transform_Move(zombie->transform, deltaTime * zombie->movementSpeed);
	zombie->circleCollider.anchor = zombie->transform->position;
}

void Enemy_showZombie(Zombie *zombie, SDL_Renderer *renderer)
{
	Draw_drawTextureWithAngle(zombie->texture, renderer, zombie->transform->position, zombie->transform->direction);
}

int Enemy_receiveDamageZombie(Zombie * zombie, unsigned short damage, double knockbackTime)
{
	zombie->health -= damage;
	zombie->knockbackTime = knockbackTime;
	if (zombie->health <= 0)
	{
		free(zombie);
		return 1;
	}
	return 0;
}
