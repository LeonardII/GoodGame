#ifndef PILLAR_H
#define PILLAR_H
#define TEXTURE_PILLAR_FILENAME "Pillar.png"
#include "transform.h"
#include "collider.h"
#include "SDL.h"
#include "enemy.h"
#include "bullet.h"
#include "player.h"
typedef struct
{
	Transform *transform;
	SDL_Texture *texture;
	CircleCollider circleCollider;
}Pillar;

Pillar *Pillar_initPillar(Vector2D position, SDL_Renderer *renderer);
void Pillar_show(Pillar *pillar, SDL_Renderer *renderer);
//Attempts to push the provided zombie if it collides with the pillar.
//Return 1, if the zombie has been pushed.
int Pillar_pushCollidingZombie(Pillar *pillar, Zombie *zombie);
//Attempts to push the provided player if it collides with the pillar.
//Return 1, if the player has been pushed.
int Pillar_pushCollidingPlayer(Pillar *pillar, Player *player);
//Attempts to destroy the provided bullet if it collides with the pillar.
//Return 1, if the bullet has been destroyed.
int Pillar_destroyCollidingBullet(Pillar *pillar, Bullet *bullet);
#endif
