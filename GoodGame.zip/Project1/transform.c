#include "transform.h"

void Transform_setDirection(Transform *transform, Vector2D direction)
{
	if (Vector2D_equals(direction, Vector2D_initEmpty()))
	{
		transform->direction = Vector2D_initVector2D(0, 1);
	}
	transform->direction = Vector2D_toUnit(direction);
}
Transform Transform_initEmpty()
{
	Transform transform;
	transform.position = Vector2D_initEmpty();
	Transform_setDirection(&transform, Vector2D_initEmpty());
	return transform;
}
Transform Transform_initTransform(Vector2D position, Vector2D direction)
{
	Transform transform;
	transform.position = position;
	Transform_setDirection(&transform, direction);
	return transform;
}
void Transform_Move(Transform *transform, double deltaTime)
{
	Vector2D vectorToMove = Vector2D_multiply(transform->direction, deltaTime);
	transform->position = Vector2D_add(transform->position, vectorToMove);
}