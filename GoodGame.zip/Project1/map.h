#ifndef MAP_H
#define MAP_H
#include "collider.h"
#include "SDL.h"
#include "pillar.h"
#include "lists.h"
#define AMOUNT_OF_PILLARS 12
typedef struct
{
	Pillar *pillars[AMOUNT_OF_PILLARS];
	//The starting position of the map. It is located at the top left of the map.
	Vector2D startPosition;
	//Is defined as (width, height).
	Vector2D size;
}Map;
//Creates a map with the given width and height.
Map *Map_initMap(Vector2D startingPosition, SDL_Renderer *renderer, unsigned int width, unsigned int height);
//Sets the pillar of the map with the matching index number at the given position. Does nothing, if the number is out of bounds.
void Map_setPillar(Map *map, int numberOfPillar, Vector2D positionOfPillar);
void Map_renderMap(Map *map, SDL_Renderer *renderer);
void Map_preventPlayerFromColliding(Map *map, Player *player);
void Map_preventZombiesFromColliding(Map *map, ZombieList *zombieList);
void Map_destroyBulletsAtColliding(Map *map, BulletList *bulletList);
#endif

