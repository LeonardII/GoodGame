//23.01.2019
//Created: 
//- collider.h
//- player.h
//-transform.h
//- vector2D.h
//25.01.2019
//Created:
//Weapon.h
//28.01.2019:
//Created:
//bullet.h
//29.01.2019:
//Created:
//draw.h
//Some Bug Fixes involving rendering the player, loading the texture, ...