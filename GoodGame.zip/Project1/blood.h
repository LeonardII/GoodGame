#pragma once
#ifndef BLOOD_H
#include "SDL.h"
#include "transform.h"
#include "draw.h"
#define BLOOD_H
#define TEXTURE_BLOOD_FILENAME "Blood.png"

typedef struct
{
	Transform *transform;
	SDL_Texture *texture;
}Blood;
//Creates an pointer of the structure Blood. Blood has no movement abilites, only a position and a texture.
Blood *Blood_initBlood(Vector2D position, SDL_Renderer *renderer);
//Shows the blood at its position.
void Blood_show(Blood *blood, SDL_Renderer *renderer);
#endif
