#ifndef WEAPON_H
#define WEAPON_H
#include <stdlib.h>
#include <SDL.h>
#include "draw.h"
#include "transform.h"
#include "bullet.h"
#define TEXTURE_WEAPON_FILENAME "Weapon.png"

typedef struct
{
	//No transform, as the weapon is dependant from the owner of the weapon.
	Vector2D position;
	Vector2D direction;
	SDL_Texture *texture;
	WeaponClass weaponClass;
	double coolDown;
	/**
	Needed because the actual cooldown is constant, but should lower over time.
	*/
	double coolDownCopy;
	Vector2D bulletSpawnPoint;
	unsigned short bulletDamage;
	unsigned short amountAmmunition;
	double bulletKnockbackTime;
	unsigned short range;
}Weapon;
/**
	Shoots a bullet if the cooldown (Copy) has disappeared.
	@param The weapon to shoot.
	@return Nothing.
*/
Bullet *Weapon_tryToShoot(Weapon *weapon, SDL_Renderer *renderer);
Weapon* Weapon_initWeapon(Vector2D position, Vector2D direction, SDL_Renderer *renderer);
//Grants the weapon the attibutes of a pistol:
//Cooldown: 0.4s
//Damage: 55 dmg
//Time of knockback: 0.2s
//Max Range: 500 units
//Ammo: 20
void Weapon_turnIntoPistol(Weapon *weapon);
//Grants the weapon the attibutes of a sniper:
//Cooldown: 1.5s
//Knockback: 1s
//Damage: 150 dmg
//Time of knockback: 1s
//Max Range: 700 units
//Ammo: 5
void Weapon_turnIntoSniper(Weapon *weapon);
//Grants the weapon the attibutes of a machine pistol:
//Cooldown: 0.08s
//Damage: 18 dmg
//Time of knockback: 0.02s
//Max Range: 250 units
//Ammo: 50
void Weapon_turnIntoMachinePistol(Weapon * weapon);
//Grants the weapon the attibutes of an assault rifle:
//Cooldown: 0.25s
//Damage: 28 dmg
//Time of knockback: 0.1s
//Max Range: 1000 units
//Ammo: 30
void Weapon_turnIntoAssaultRifle(Weapon * weapon);
//Grants the weapon the attibutes of a machine gun:
//Cooldown: 0.05s
//Damage: 11 dmg
//Time of knockback: 0.2s
//Max Range: 600 units
//Ammo: 100
void Weapon_turnIntoMachineGun(Weapon * weapon);
// afoFAnagoFI=ige?
void Weapon_turnIntoShotgun(Weapon *weapon);
//Sets the position of the weapon with the new position, ignoring what the previous position was.
void Weapon_resetPosition(Weapon *weapon, Vector2D newPosition);
//Sets the direction of the weapon with the new position, ignoring what the previous direction was.
void Weapon_resetDirection(Weapon *weapon, Vector2D newDirection);
void Weapon_show(Weapon *weapon, SDL_Renderer *renderer);
//Decreases the cooldown of the weapon by the deltaTime of the frame.
void Weapon_decreaseCooldown(Weapon* weapon, double deltaTime);
#endif // !WEAPON_H
