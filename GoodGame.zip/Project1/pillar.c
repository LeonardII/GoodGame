#include "pillar.h"

Pillar * Pillar_initPillar(Vector2D position, SDL_Renderer * renderer)
{
	Pillar *pillar = malloc(sizeof(Pillar));
	pillar->transform = malloc(sizeof(Pillar));
	pillar->transform->position = position;
	Transform_setDirection(pillar->transform, Vector2D_initVector2D(0, 1));
	pillar->circleCollider.anchor = position;
	int diameter = 0;
	pillar->texture = Draw_loadTexture(TEXTURE_PILLAR_FILENAME, renderer, &diameter);
	pillar->circleCollider.radius = diameter / 2;

	return pillar;
}

void Pillar_show(Pillar * pillar, SDL_Renderer * renderer)
{
	Draw_drawTextureWithAngle(pillar->texture, renderer, pillar->transform->position, pillar->transform->direction);
}

int Pillar_pushCollidingZombie(Pillar * pillar, Zombie * zombie)
{
	if (CircleCollider_isColliding(pillar->circleCollider, zombie->circleCollider))
	{
		Vector2D distanceBetweenAnchors = Vector2D_subtract(pillar->circleCollider.anchor, zombie->circleCollider.anchor);
		double currentDistance = Vector2D_getMagnitude(distanceBetweenAnchors);
		Vector2D distanceAsANorm = Vector2D_toUnit(distanceBetweenAnchors);
		Vector2D vectorForReshifting = Vector2D_multiply(distanceAsANorm, (pillar->circleCollider.radius + zombie->circleCollider.radius - currentDistance));
		zombie->transform->position = Vector2D_subtract(zombie->transform->position, vectorForReshifting);
		zombie->circleCollider.anchor = zombie->transform->position;
		return 1;
	}
	return 0;
}

int Pillar_pushCollidingPlayer(Pillar * pillar, Player * player)
{
	if (CircleCollider_isColliding(pillar->circleCollider, player->circleCollider))
	{
		Vector2D distanceBetweenAnchors = Vector2D_subtract(pillar->circleCollider.anchor, player->circleCollider.anchor);
		double currentDistance = Vector2D_getMagnitude(distanceBetweenAnchors);
		Vector2D distanceAsANorm = Vector2D_toUnit(distanceBetweenAnchors);
		Vector2D vectorForReshifting = Vector2D_multiply(distanceAsANorm, (pillar->circleCollider.radius + player->circleCollider.radius - currentDistance));
		player->transform->position = Vector2D_subtract(player->transform->position, vectorForReshifting);
		player->circleCollider.anchor = player->transform->position;
		return 1;
	}
	return 0;
}

int Pillar_destroyCollidingBullet(Pillar * pillar, Bullet * bullet)
{
	if (CircleCollider_isColliding(pillar->circleCollider, bullet->circleCollider))
	{
		free(bullet);
		return 1;
	}
	return 0;
}
