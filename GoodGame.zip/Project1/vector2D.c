#include "vector2D.h"
#include <math.h>
#define M_PI 3.14159265358979323846

Vector2D Vector2D_initEmpty()
{
	return Vector2D_initVector2D(0, 0);
}
Vector2D Vector2D_initVector2D(double x, double y)
{
	Vector2D vectorToReturn;
	vectorToReturn.x = x;
	vectorToReturn.y = y;
	return vectorToReturn;
}
double Vector2D_getMagnitude(Vector2D vectorToCheck)
{
	return pow(pow(vectorToCheck.x, 2) + pow(vectorToCheck.y, 2), 0.5);
}
double Vector2D_getDotProduct(Vector2D vector1, Vector2D vector2)
{
	return vector1.x * vector2.x + vector1.y * vector2.y;
}
double Vector2D_getRadiansBetween(Vector2D vector1, Vector2D vector2)
{
	return acos(Vector2D_getDotProduct(vector1, vector2) / (Vector2D_getMagnitude(vector1) * Vector2D_getMagnitude(vector2)));
}
double Vector2D_getDegreesClockwise(Vector2D vec) {
	double radian;
	if (vec.x >= 0) {
		radian = atan(vec.y / vec.x)+ M_PI*3/2;
	}
	else {
		radian = atan(vec.y / vec.x) + M_PI/2;
	}
	return radian / (2 * M_PI) * 360;
}
int Vector2D_equals(Vector2D vector1, Vector2D vector2)
{
	if (vector1.x == vector2.x && vector1.y == vector2.y)
	{
		return 1;
	}
	return 0;
}
Vector2D Vector2D_add(Vector2D v1, Vector2D v2)
{
	return Vector2D_initVector2D(v1.x + v2.x, v1.y + v2.y);
}
Vector2D Vector2D_subtract(Vector2D v1, Vector2D v2)
{
	return Vector2D_initVector2D(v1.x - v2.x, v1.y - v2.y);
}
Vector2D Vector2D_multiply(Vector2D vectorToScale, double scalar)
{
	return Vector2D_initVector2D(vectorToScale.x * scalar, vectorToScale.y * scalar);
}
Vector2D Vector2D_divide(Vector2D vectorToScale, double scalar)
{
	return Vector2D_initVector2D(vectorToScale.x / scalar, vectorToScale.y / scalar);
}
Vector2D Vector2D_toUnit(Vector2D vectorToConvert)
{
	return Vector2D_divide(vectorToConvert, Vector2D_getMagnitude(vectorToConvert));
}