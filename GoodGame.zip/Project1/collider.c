#include "collider.h"

int RectangleCollider_isColliding(RectangleCollider collider1, RectangleCollider collider2)
{
	if (collider1.positionTopLeft.x > collider2.positionBottomRight.x || collider2.positionTopLeft.x > collider1.positionBottomRight.x)
	{
		return 0;
	}
	if (collider1.positionTopLeft.y < collider2.positionBottomRight.y || collider2.positionTopLeft.y < collider1.positionBottomRight.y)
	{
		return 0;
	}
}
int RectangleCollider_isInside(RectangleCollider collider, Vector2D pointToCheck)
{
	if (pointToCheck.x >= collider.positionTopLeft.x && pointToCheck.x <= collider.positionBottomRight.x && pointToCheck.y >= collider.positionBottomRight.y && pointToCheck.y <= collider.positionTopLeft.y)
	{
		return 1;
	}
	return 0;
}
int CircleCollider_isColliding(CircleCollider collider1, CircleCollider collider2)
{
	double radiusSum = collider1.radius + collider2.radius;
	Vector2D distanceVector = Vector2D_subtract(collider1.anchor, collider2.anchor);
	if (Vector2D_getMagnitude(distanceVector) > radiusSum)
	{
		return 0;
	}
	return 1;
}