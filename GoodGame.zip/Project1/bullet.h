#pragma once
#include "transform.h"
#include "collider.h"
#include "SDL.h"
#include "draw.h"

#define TEXTURE_BULLET_FILENAME "Bullet.png"
typedef enum
{
	Pistol, Sniper, MachinePistol, AssaultRifle, MachineGun, None
}WeaponClass;
typedef struct
{
	Transform *transform;
	CircleCollider circleCollider;
	SDL_Texture *texture;
	WeaponClass weaponClass;
	unsigned short damage;
	double knockbackTime;
	double remainingRange;
	unsigned short speed;
}
Bullet;
Bullet *Bullet_initBullet(Vector2D position, Vector2D direction, SDL_Renderer *renderer, WeaponClass weaponClass, unsigned short damage, double knockbackTime, double totalRange);
//Moves the bullet depending on the deltaTime.
//@return 1, if the bullet has no remaining range left. In that case, destroys the bullet.
int Bullet_move(Bullet *bullet, double deltaTime);
//Shows the bullet depending at its position.
void Bullet_show(Bullet *bullet, SDL_Renderer *renderer);
//Instantly destroys the bullet, turning the pointer into a NULL pointer.
void Bullet_destroy(Bullet *bullet);

