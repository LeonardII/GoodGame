#include "blood.h"

Blood * Blood_initBlood(Vector2D position, SDL_Renderer * renderer)
{
	Blood *blood = malloc(sizeof(Blood));
	blood->transform = malloc(sizeof(Transform));
	blood->transform->position = position;
	Transform_setDirection(blood->transform, Vector2D_initVector2D(0, 1));
	blood->texture = Draw_loadTexture(TEXTURE_BLOOD_FILENAME, renderer, NULL);
	return blood;
}

void Blood_show(Blood * blood, SDL_Renderer * renderer)
{
	Draw_drawTextureWithAngle(blood->texture, renderer, blood->transform->position, blood->transform->direction);
}
