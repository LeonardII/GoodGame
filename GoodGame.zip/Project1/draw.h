#ifndef DRAW_H
#define DRAW_H
#include "SDL.h"
#include "vector2D.h"
#include "SDL_image.h"
#include <stdio.h>
//Loads a texture with the given filename. 
//If an integer for the size is provided, the value of this pointer will be given of the size of the texture.
//Returns the texture, if sucessful, otherwise NULL.
SDL_Texture *Draw_loadTexture(char *filename, SDL_Renderer *renderer, int *size);
//Draws the provided texture, positioned at the given center. 
void Draw_drawTexture(SDL_Texture *textureToDraw, SDL_Renderer *renderer, Vector2D center);
//Draws the provided texture, positioned at the given center and facing the provided direction. 
void Draw_drawTextureWithAngle(SDL_Texture *textureToDraw, SDL_Renderer *renderer, Vector2D center, Vector2D direction);
#endif