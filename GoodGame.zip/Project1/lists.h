#pragma once
#include "bullet.h"
#include "enemy.h"
#include "blood.h"
#include "pickup.h"
#include <stdlib.h>
typedef struct
{
	Bullet *bullets[1000];
	unsigned int length;
}BulletList;
typedef struct
{
	Zombie *zombies[1000];
	unsigned int length;
}ZombieList;
typedef struct
{
	int *numbers[1000];
	unsigned int length;
}IntegerList;
typedef struct
{
	Blood *bloods[1000];
	unsigned int length;
}BloodList;
typedef struct
{
	PickUp *pickUps[1000];
	unsigned int length;
}PickUpList;
BulletList *BulletList_initBulletList(); 
//Adds the provided bullet to the end of the list.
void BulletList_add(BulletList *list, Bullet *bullet);
//Removes the bullet with the matching index and adapts the list afterwards to prevent any NULL pointers.
void BulletList_removeByIndex(BulletList *list, unsigned short index);
//Renders every existing bullet in the list.
void BulletList_renderBullets(BulletList *list, SDL_Renderer *renderer);
//Moves every existing bullet in the list. If the range of the bullet is exhausted, it will be removed instantly.
void BulletList_moveBullets(BulletList *list, double deltaTime);
ZombieList *ZombieList_initZombieList();
//Adds the provided zombie to the end of the list.
void ZombieList_add(ZombieList *list, Zombie *zombie);
//Removes the zombie with the matching index and adapts the list afterwards to prevent any NULL pointers.
void ZombieList_removeByIndex(ZombieList *list, unsigned short index);
//Renders every existing zombie in the list.
void ZombieList_renderZombies(ZombieList *list, SDL_Renderer *renderer);
//Moves every existing zombie in the list.
void ZombieList_moveZombies(ZombieList *list, double deltaTime);
//Prevents the zombies from colliding with each other.
void ZombieList_preventZombiesFromColliding(ZombieList *zombieList);
//Checks whether the zombies collide with the player.
//If they do, the player will be killed and this function will return 1.
int ZombieList_tryToHitPlayer(Player *player, ZombieList *zombieList);
IntegerList *IntegerList_initIntegerList();
void IntegerList_add(IntegerList *integerlist, int value);
BloodList *BloodList_initBloodList();
void BloodList_add(BloodList *bloodList, Blood *blood);
//Shows every blood in the list.
void BloodList_renderBloods(BloodList *bloodList, SDL_Renderer *renderer);
PickUpList *PickUpList_initPickUpList();
void PickUpList_add(PickUpList *list, PickUp *pickUp);
void PickUpList_removeByIndex(PickUpList *list, unsigned short index);
void PickUpList_renderPickUps(PickUpList *list, SDL_Renderer *renderer);
//Checks, whether the player collides with any pickups.
//Return 1, if it does and has is weapon transformed.
int PickUpList_checkCollidingwithPlayer(PickUpList *list, Player *player);
//Checks all bullet colliders and zombie colliders.
//Applies damage and destruction, if they are colliding.
//Return 1, if a zombie get killed.
int List_applyDamageOnZombiesOnCollide(BulletList *bulletList, ZombieList *zombieList, BloodList *bloodList, PickUpList *pickUpList, unsigned short probabiltyOfDrop, SDL_Renderer *renderer);