#include "lists.h"
BulletList *BulletList_initBulletList()
{
	BulletList *bulletList;
	bulletList = malloc(sizeof(BulletList));
	bulletList->length = 0;
	return bulletList;
}
void BulletList_add(BulletList *bulletList, Bullet *bullet)
{
	bulletList->bullets[bulletList->length] = bullet;
	bulletList->length++;
}
void BulletList_removeByIndex(BulletList *list, unsigned short index)
{
	if (index >= list->length)
	{
		return;
	}
	list->bullets[index] = NULL;
	int i;
	for (i = index; i < list->length - 1; i++)
	{
		list->bullets[i] = list->bullets[i + 1];
	}
	//Not using free(), because list->bullets[list->length - 1] points to the same element as list->bullets[list->length - 2]. Ask Viet for details.
	list->bullets[list->length - 1] = NULL;
	list->length--;
}
void BulletList_moveBullets(BulletList *list, double deltaTime)
{
	if (list->length == 0)
	{
		return;
	}
	int i = 0;
	for (i = 0; i <= (int)list->length - 1; i++)
	{
		if (list->bullets[i] == NULL)
		{
			//Should not occur.
			printf_s("Error for index: %u with length: %u.", i, list->length);
			continue;
		}
		if (Bullet_move(list->bullets[i], deltaTime) == 1)
		{
			BulletList_removeByIndex(list, i);
		}
	}
}
ZombieList * ZombieList_initZombieList()
{
	ZombieList *zombieList;
	zombieList = malloc(sizeof(ZombieList));
	zombieList->length = 0;
	return zombieList;
}
void ZombieList_add(ZombieList * list, Zombie * zombie)
{
	list->zombies[list->length] = zombie;
	list->length++;
}
void ZombieList_removeByIndex(ZombieList * list, unsigned short index)
{
	if (index >= list->length)
	{
		return;
	}
	list->zombies[index] = NULL;
	int i;
	for (i = index; i < list->length - 1; i++)
	{
		list->zombies[i] = list->zombies[i + 1];
	}
	//Not using free(), because list->zombies[list->length - 1] points to the same element as list->zombies[list->length - 2]. Ask Viet for details.
	list->zombies[list->length - 1] = NULL;
	list->length--;
}
void ZombieList_moveZombies(ZombieList *list, double deltaTime)
{
	if (list->length == 0)
	{
		return;
	}
	int i = 0;
	for (i = 0; i <= (int)list->length - 1; i++)
	{
		Enemy_moveZombie(list->zombies[i], deltaTime);
	}
}
void ZombieList_preventZombiesFromColliding(ZombieList * zombieList)
{
	for (int i = 0; i <= (int) zombieList->length - 2; i++)
	{
		//To prevent the collider comparing itself, the index settings have been slightly modified. (i != index of last zombie, j != i)
		for (int j = i + 1; j < zombieList->length; j++)
		{
			if (CircleCollider_isColliding(zombieList->zombies[i]->circleCollider, zombieList->zombies[j]->circleCollider))
			{
				Vector2D distanceBetweenAnchors = Vector2D_subtract(zombieList->zombies[i]->circleCollider.anchor, zombieList->zombies[j]->circleCollider.anchor);
				double currentDistance = Vector2D_getMagnitude(distanceBetweenAnchors);
				Vector2D distanceAsANorm = Vector2D_toUnit(distanceBetweenAnchors);
				Vector2D vectorForReshifting = Vector2D_multiply(distanceAsANorm, (2 * zombieList->zombies[i]->circleCollider.radius - currentDistance) / 2);
				zombieList->zombies[i]->transform->position = Vector2D_add(zombieList->zombies[i]->transform->position, vectorForReshifting);
				zombieList->zombies[i]->circleCollider.anchor = zombieList->zombies[i]->transform->position;
				zombieList->zombies[j]->transform->position = Vector2D_subtract(zombieList->zombies[j]->transform->position, vectorForReshifting);
				zombieList->zombies[j]->circleCollider.anchor = zombieList->zombies[j]->transform->position;
			}
		}
	}
}
IntegerList * IntegerList_initIntegerList()
{
	IntegerList *integerList;
	integerList = malloc(sizeof(IntegerList));
	integerList->length = 0;
	return integerList;
}
void IntegerList_add(IntegerList * integerList, int value)
{
	integerList->numbers[integerList->length] = value;
	integerList->length++;
}
BloodList * BloodList_initBloodList()
{
	BloodList *bloodList;
	bloodList = malloc(sizeof(BloodList));
	bloodList->length = 0;
	return bloodList;
}
void BloodList_add(BloodList * bloodList, Blood * blood)
{
	bloodList->bloods[bloodList->length] = blood;
	bloodList->length++;
}
void BloodList_renderBloods(BloodList * bloodList, SDL_Renderer * renderer)
{
	if (bloodList->length == 0)
	{
		return;
	}
	int i;
	for (i = 0; i <= bloodList->length - 1; i++)
	{
		Blood_show(bloodList->bloods[i], renderer);
	}
}
PickUpList * PickUpList_initPickUpList()
{
	PickUpList *pickUpList;
	pickUpList = malloc(sizeof(PickUpList));
	pickUpList->length = 0;
	return pickUpList;
}
void PickUpList_add(PickUpList * list, PickUp * pickUp)
{
	list->pickUps[list->length] = pickUp;
	list->length++;
}
void PickUpList_removeByIndex(PickUpList * list, unsigned short index)
{
	if (index >= list->length)
	{
		return;
	}
	list->pickUps[index] = NULL;
	int i;
	for (i = index; i < list->length - 1; i++)
	{
		list->pickUps[i] = list->pickUps[i + 1];
	}
	//Not using free(), because list->zombies[list->length - 1] points to the same element as list->zombies[list->length - 2]. Ask Viet for details.
	list->pickUps[list->length - 1] = NULL;
	list->length--;
}
void PickUpList_renderPickUps(PickUpList * list, SDL_Renderer * renderer)
{
	for (int i = 0; i < list->length; i++)
	{
		PickUp_show(list->pickUps[i], renderer);
	}
}
int PickUpList_checkCollidingwithPlayer(PickUpList * list, Player *player)
{
	for (int i = 0; i < list->length; i++)
	{
		if (PickUp_grantPlayerWeaponIfColliding(list->pickUps[i], player))
		{
			PickUpList_removeByIndex(list, i);
			return 1;
		}
	}
	return 0;
}
void ZombieList_renderZombies(ZombieList * list, SDL_Renderer * renderer)
{
	if (list->length == 0)
	{
		return;
	}
	int i;
	for (i = 0; i <= list->length - 1; i++)
	{
		Enemy_showZombie(list->zombies[i], renderer);
	}
}
void BulletList_renderBullets(BulletList *list, SDL_Renderer *renderer)
{
	if (list->length == 0)
	{
		return;
	}
	int i;
	for (i = 0; i <= list->length - 1; i++)
	{
		Bullet_show(list->bullets[i], renderer);
	}
}
int List_applyDamageOnZombiesOnCollide(BulletList * bulletList, ZombieList * zombieList, BloodList * bloodList, PickUpList *pickUpList, unsigned short probabilityOfDrop, SDL_Renderer * renderer)
{
	if (bulletList->length == 0 || zombieList->length == 0)
	{
		return 0;
	}
	int i, j, zombieDead = 0;
	for (i = 0; i <= (int)bulletList->length - 1; i++)
	{
		for (j = 0; j <= (int)zombieList->length - 1; j++)
		{
			if (bulletList->length == 0 || zombieList->length == 0)
			{
				return 0;
			}
			if (i >= (int)bulletList->length)
			{
				return 0;
			}
			if (CircleCollider_isColliding(bulletList->bullets[i]->circleCollider, zombieList->zombies[j]->circleCollider))
			{
				Vector2D positionOfZombie = zombieList->zombies[j]->transform->position;
				unsigned short actualDamage = bulletList->bullets[i]->damage;
				if (Enemy_receiveDamageZombie(zombieList->zombies[j], actualDamage, bulletList->bullets[i]->knockbackTime))
				{
					Blood *blood = Blood_initBlood(positionOfZombie, renderer);
					BloodList_add(bloodList, blood);
					if (probabilityOfDrop >= rand() % 101)
					{
						PickUp *pickUp = PickUp_initRandomPickUp(positionOfZombie, renderer);
						PickUpList_add(pickUpList, pickUp);
					}
					ZombieList_removeByIndex(zombieList, j);
					zombieDead = 1;
				}
				if (bulletList->bullets[i]->weaponClass != Sniper)
				{
					Bullet_destroy(bulletList->bullets[i]);
					BulletList_removeByIndex(bulletList, i);
				}
			}
		}
	}
	return zombieDead;
}
int ZombieList_tryToHitPlayer(Player *player, ZombieList *zombieList)
{
	for (int i = 0; i < zombieList->length; i++)
	{
		if (CircleCollider_isColliding(player->circleCollider, zombieList->zombies[i]->circleCollider))
		{
			Player_die(player);
			return 1;
		}
	}
	return 0;
}