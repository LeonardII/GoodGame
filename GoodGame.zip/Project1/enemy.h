#ifndef ENEMY_H
#define ENEMY_H
#include <stdlib.h>
#include "transform.h"
#include "collider.h"
#include "player.h"
#include "SDL.h"
#define TEXTURE_ZOMBIE_FILENAME "Zombie.png"
#define HEALTH 100
#define MOVEMENT_SPEED 0.22;
typedef struct
{
	Transform *transform;
	Transform *transformTarget;
	CircleCollider circleCollider;
	SDL_Texture *texture;
	short health;
	double movementSpeed;
	//Prevents the zombie from moving during this time.
	double knockbackTime; 
}Zombie;

Zombie *Enemy_spawnZombie(Player *target, Vector2D spawnPosition, SDL_Renderer *renderer);
//Moves the zombie awith the given delta time.
void Enemy_moveZombie(Zombie *zombie, double deltaTime);
//Applies the received damage on the health of the zombie.
//Return 1, if the health is lower than 0 and the zombie is freed.
int Enemy_receiveDamageZombie(Zombie *zombie, unsigned short damage, double knockbackTime);
//Shows the zombie...
void Enemy_showZombie(Zombie *zombie, SDL_Renderer *renderer);
#endif