#ifndef PLAYER_H
#define PLAYER_H
#include "transform.h"
#include "collider.h"
#include "weapon.h"
#include "SDL.h"
#include "draw.h"

#define TEXTURE_PLAYER_FILENAME "Player.png"

typedef struct
{
	double movementSpeed;
	double timeLengthOfKnockback;
	Transform *transform;
	Weapon *weapon;
	Vector2D textureDirection;
	CircleCollider circleCollider;
	SDL_Texture *texture;
	int isAlive;
}Player;

/**
	Creates a player with the given parameters without any needed direction or transform. The filename and renderer are needed to display the player.
*/
Player* Player_initPlayerOverload(double movementSpeed, Vector2D position, SDL_Renderer *renderer);
/**
	Creates a player with the given parameters. The filename and renderer are needed to display the player.
*/
Player* Player_initPlayer(double movementSpeed, Transform *transform, SDL_Renderer *renderer);
/**
	Moves the transform instantly by its direction AND movement speed.
	Does not move the player if it is not alive.
	@params ONLY the time needed to 'teleport' the player.
	@return It's VOID.
*/
void Player_move(Player *player, SDL_Renderer *renderer, double deltaTime);
/**
	Moves the transform instantly by its new set direction AND movement speed. Does not move if the new direction is zero..
	@params ONLY the time needed to 'teleport' the player and the new direction to go to.
	@return It's VOID.
*/
void Player_moveWithNewDirection(Player * player, SDL_Renderer *renderer, Vector2D newDirection, double deltaTime);

void Player_receiveKnockback(Player *player, double timeLengthofKnockback);
/**
	Shows the texture of the player.
*/
void Player_show(Player *player, SDL_Renderer *renderer);
/**
	Shows the texture of the player without setting the player direction. 
*/
void Player_showWithNewDirection(Player *player, SDL_Renderer *renderer, Vector2D textureDirection);
/**
	Does everything necessary to show GAME OVER.
*/
void Player_die(Player *player);
#endif

