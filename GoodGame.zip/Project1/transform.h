#ifndef TRANSFORM_H
#define TRANSFORM_H

#include "vector2D.h"

typedef struct
{
	Vector2D position;
	/**
	DON'T manipulate it directly! Use Transform_setDirection() instead.
	*/
	Vector2D direction;
} Transform;

/**
	Sets the direction of the provided transform with as an unit vector.
	@param the transform to manipulate and the direction to set.
	@return It's a void function -.- .
*/
void Transform_setDirection(Transform *transform, Vector2D direction);
/**
	Creates a transform without giving its properties any values.
	@return A transform with a position (0/0) und a direction (0/0).
*/
Transform Transform_initEmpty();
Transform Transform_initTransform(Vector2D position, Vector2D direction);
/**
	Moves the transform instantly by its direction.
	@params The time needed to 'teleport' the transform.
	@return It's a VOID function.
*/
void Transform_Move(Transform *transform, double deltaTime);
#endif
