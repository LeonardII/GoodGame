#ifndef COLLIDER_H
#define COLLIDER_H
#include "vector2D.h"
typedef struct
{
	Vector2D positionTopLeft;
	Vector2D positionBottomRight;
} RectangleCollider;
typedef struct
{
	Vector2D anchor;
	double radius;
}CircleCollider;
/**
	Checks if two circle colliders overlap.
	@param the colliders to check.
	@return 1 if they do overlap, 0 if not.
*/
int CircleCollider_isColliding(CircleCollider collider1, CircleCollider collider2);
/**
	Checks if two rectangle colliders overlap.
	@param the colliders to check.
	@return 1 if they do overlap, 0 if not.
*/
int RectangleCollider_isColliding(RectangleCollider collider1, RectangleCollider collider2);
/**
	Checks whether the point of the vector is inside the rectangle.
	Returns 1, if it does.
*/
int RectangleCollider_isInside(RectangleCollider collider, Vector2D pointToCheck);
#endif
