#include "weapon.h"
Bullet *Weapon_tryToShoot(Weapon *weapon, SDL_Renderer *renderer)
{
	if (weapon->amountAmmunition == 0)
	{
		return NULL;
	}
	if (weapon->coolDownCopy <= 0)
	{
		//Create bullet
		Bullet *bullet = Bullet_initBullet(Vector2D_add(weapon->position, Vector2D_toUnit(weapon->direction)), weapon->direction, renderer, weapon->weaponClass, weapon->bulletDamage, weapon->bulletKnockbackTime, weapon->range);
		weapon->amountAmmunition--;
		weapon->coolDownCopy = weapon->coolDown;
		return bullet;
	}
	return NULL;
}
Weapon* Weapon_initWeapon(Vector2D position, Vector2D direction, SDL_Renderer *renderer)
{
	Weapon *weapon = malloc(sizeof(Weapon));
	weapon->weaponClass = None;
	weapon->position = position;
	weapon->direction = direction;
	weapon->texture = Draw_loadTexture(TEXTURE_WEAPON_FILENAME, renderer, NULL);
	weapon->amountAmmunition = 0;
	return weapon;
}

void Weapon_turnIntoPistol(Weapon * weapon)
{
	weapon->coolDown = 0.4;
	weapon->coolDownCopy = 0;
	weapon->bulletKnockbackTime = 0.2;
	weapon->bulletDamage = 55;
	weapon->range = 700;
	weapon->weaponClass = Pistol;
	weapon->amountAmmunition = 20;
}

void Weapon_turnIntoSniper(Weapon * weapon)
{
	weapon->coolDown = 1.5;
	weapon->coolDownCopy = 0;
	weapon->bulletKnockbackTime = 1;
	weapon->bulletDamage = 150;
	weapon->range = 2000;
	weapon->weaponClass = Sniper;
	weapon->amountAmmunition = 5;
}
void Weapon_turnIntoAssaultRifle(Weapon * weapon)
{
	weapon->coolDown = 0.25;
	weapon->coolDownCopy = 0;
	weapon->bulletKnockbackTime = 0.1;
	weapon->bulletDamage = 28;
	weapon->range = 1000;
	weapon->weaponClass = AssaultRifle;
	weapon->amountAmmunition = 30;
}
//void Weapon_turnIntoShotgun(Weapon * weapon)
//{
//	weapon->coolDown = 1.2;
//	weapon->coolDownCopy = 0;
//	weapon->bulletKnockbackTime = 0.8;
//	weapon->bulletDamage = 80;
//	weapon->range = 150;
//	weapon->weaponClass = Shotgun;
//}
void Weapon_turnIntoMachinePistol(Weapon * weapon)
{
	weapon->coolDown = 0.08;
	weapon->coolDownCopy = 0;
	weapon->bulletKnockbackTime = 0.02;
	weapon->bulletDamage = 18;
	weapon->range = 250;
	weapon->weaponClass = MachinePistol;
	weapon->amountAmmunition = 50;
}
void Weapon_turnIntoMachineGun(Weapon * weapon)
{
	weapon->coolDown = 0.05;
	weapon->coolDownCopy = 0;
	weapon->bulletKnockbackTime = 0.2;
	weapon->bulletDamage = 11;
	weapon->range = 600;
	weapon->weaponClass = MachineGun;
	weapon->amountAmmunition = 100;
}
void Weapon_resetPosition(Weapon *weapon, Vector2D newPosition)
{
	weapon->position = newPosition;
}

void Weapon_resetDirection(Weapon * weapon, Vector2D newDirection)
{
	weapon->direction = newDirection;
}

void Weapon_show(Weapon * weapon, SDL_Renderer * renderer)
{
	Draw_drawTextureWithAngle(weapon->texture, renderer, weapon->position, weapon->direction);
}

void Weapon_decreaseCooldown(Weapon * weapon, double deltaTime)
{
	if (weapon->coolDownCopy <= 0)
	{
		return;
	}
	weapon->coolDownCopy -= deltaTime / (double) 1000;
}
