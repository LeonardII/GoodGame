#ifndef VECTOR2D_H
#define VECTOR2D_H


typedef struct
{
	double x;
	double y;
} Vector2D;
/**
	Constructs the null vector.
	@return the vector (0/0).
*/
Vector2D Vector2D_initEmpty();
/**
	Constructs a twodimensional vector.
	@param the coordinates of the vector.
	@return a vector with the given coordinates.
*/
Vector2D Vector2D_initVector2D(double x, double y);
int Vector2D_equals(Vector2D vector1, Vector2D vector2);
Vector2D Vector2D_add(Vector2D vector1, Vector2D vector2);
Vector2D Vector2D_subtract(Vector2D vector1, Vector2D vector2);
Vector2D Vector2D_multiply(Vector2D vectorToScale, double scalar);
Vector2D Vector2D_divide(Vector2D vectorToScale, double scalar);
///<summary>
///Converts a vector to its unit without transforming itself.
///</summary>
Vector2D Vector2D_toUnit(Vector2D vectorToConvert);
///<summary>
///Returns the length of the provided vector.
///</summary>
double Vector2D_getMagnitude(Vector2D vectorToCheck);
double Vector2D_getDegreesClockwise(Vector2D vector);
double Vector2D_getDotProduct(Vector2D vector1, Vector2D vector2);
double Vector2D_getRadiansBetween(Vector2D vector1, Vector2D vector2);
#endif 