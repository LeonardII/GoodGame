#include "map.h"

Map * Map_initMap(Vector2D startingPosition, SDL_Renderer * renderer, unsigned int width, unsigned int height)
{
	Map *map = malloc(sizeof(Map));
	map->startPosition = startingPosition;
	map->size.x = width;
	map->size.y = height;
	for (int i = 0; i < AMOUNT_OF_PILLARS; i++)
	{
		map->pillars[i] = Pillar_initPillar(Vector2D_initEmpty(), renderer);
	}
	return map;
}
void Map_setPillar(Map * map, int numberOfPillar, Vector2D positionOfPillar)
{
	if (numberOfPillar < 0 || numberOfPillar >= AMOUNT_OF_PILLARS)
	{
		printf_s("Wrong pillar number!");
		return;
	}
	map->pillars[numberOfPillar]->transform->position = positionOfPillar;
	map->pillars[numberOfPillar]->circleCollider.anchor = positionOfPillar;
}
void Map_renderMap(Map *map, SDL_Renderer *renderer)
{
	for (int i = 0; i < AMOUNT_OF_PILLARS; i++)
	{
		Pillar_show(map->pillars[i], renderer);
	}
}

void Map_preventPlayerFromColliding(Map * map, Player * player)
{
	for (int i = 0; i < AMOUNT_OF_PILLARS; i++)
	{
		Pillar_pushCollidingPlayer(map->pillars[i], player);
	}
}

void Map_preventZombiesFromColliding(Map * map, ZombieList * zombieList)
{
	for (int i = 0; i < AMOUNT_OF_PILLARS; i++)
	{
		for (int j = 0; j < zombieList->length; j++)
		{
			Pillar_pushCollidingZombie(map->pillars[i], zombieList->zombies[j]);
		}
	}
}

void Map_destroyBulletsAtColliding(Map * map, BulletList * bulletList)
{
	for (int i = 0; i < AMOUNT_OF_PILLARS; i++)
	{
		for (int j = 0; j < bulletList->length; j++)
		{
			if (Pillar_destroyCollidingBullet(map->pillars[i], bulletList->bullets[j]))
			{
				BulletList_removeByIndex(bulletList, j);
			}
		}
	}
}
