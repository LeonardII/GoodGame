#include "draw.h"
#include <math.h>

SDL_Texture *Draw_loadTexture(char *filename, SDL_Renderer *renderer, int *size)
{
	SDL_Texture *texture;
	SDL_Surface *surface;
	//SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "Loading %s", filename);
	surface = IMG_Load(filename);
	texture = SDL_CreateTextureFromSurface(renderer, surface);
	if (texture == NULL)
		printf_s(SDL_GetError());
	else if (size == NULL)
	{

	}
	else
	{
		SDL_Rect dest;
		SDL_QueryTexture(texture, NULL, NULL, &dest.w, &dest.h);
		*size = dest.w;
	}
	return texture;
}
void Draw_drawTexture(SDL_Texture *textureToDraw, SDL_Renderer *renderer, Vector2D center)
{
	SDL_Rect dest;
	dest.x = (int) center.x;
	dest.y = (int) center.y;
	SDL_QueryTexture(textureToDraw, NULL, NULL, &dest.w, &dest.h);

	dest.x -= (int)(dest.w * (double) 0.5);
	dest.y -= (int)(dest.h * (double) 0.5);

	SDL_RenderCopy(renderer, textureToDraw, NULL, &dest);
}
void Draw_drawTextureWithAngle(SDL_Texture *textureToDraw, SDL_Renderer *renderer, Vector2D center, Vector2D direction)
{
	SDL_Rect dest;
	dest.x = (int) center.x;
	dest.y = (int) center.y;
	SDL_QueryTexture(textureToDraw, NULL, NULL, &dest.w, &dest.h);

	dest.x -= (int)(dest.w * (double) 0.5);
	dest.y -= (int)(dest.h * (double) 0.5);

	SDL_RenderCopyEx(renderer, textureToDraw, NULL, &dest, Vector2D_getDegreesClockwise(direction), NULL, 0);
}